# AlmostMake

A pure-python, not-quite-POSIX-compliant implementation of make.

## Testing

To test AlmostMake, run,
```sh
$ cd tests
$ python3 ../make
```
